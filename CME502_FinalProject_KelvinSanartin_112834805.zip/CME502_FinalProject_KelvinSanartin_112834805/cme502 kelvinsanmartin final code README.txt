kelvin sanmartin
112834805
python project readme file

Main Code is the primary location where the data frames and plots are being created. Several
plots are created, but may be pushed up due to the code in the following two functions

[ln191] identifyPeaks uses find_peaks from scipy.signallocates the indicies of the 
relative maximum (peaks) and linearly scales the index to the appropriate wavelength.
Returns index for data manipulation, and wavelength for characterization purposes.
Uncomment [ln205] to verify peak wavelength

[ln207]charPeaks prints out what functional group each wavelength might be according to 
a glossary provided by UCLA. For the purposes of keeping the console clean of clutter, only
one FTIR plot is used as an example. Any data array would work. [ln270] is commented out
to allow only plots to show. Uncomment to utilize function