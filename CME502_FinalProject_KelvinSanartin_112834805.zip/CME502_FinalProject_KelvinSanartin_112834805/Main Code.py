#Kelvin Sanmartin
#112834805
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.signal import find_peaks

#this is my super cool python project.
#Simplify dataframe creation process
directory = "/Users/kelvi/Desktop/CME502/Project Files/"
fileNameInput = "Pure Cotton-Wool"
fileNameInput2 = "Pure Cotton"
fileNameInput3 = "Pure Wool"
fileNameInputA = "Pure IL"
fileNameInputB = "Recycled IL"
fileNameInput4 = "Recovered Cotton-Wool"

#Create dataframes for pure cotton, pure wool, pure cotton-wool blend
df_pureCW = pd.read_csv(directory+fileNameInput+".csv")
df_pureC = pd.read_csv(directory+fileNameInput2+".csv")
df_pureW = pd.read_csv(directory+fileNameInput3+".csv")
#pick any dataframe to extract wavelength range
wv = df_pureCW['Wavenumber']

#Create dataframe for recovered cotton-wool
df_recCW = pd.read_csv(directory+fileNameInput4+".csv")

#Create dataframes for pure IL, and trials of recovered IL
df_pureIL = pd.read_csv(directory+fileNameInputA+".csv")
df_recIL = pd.read_csv(directory+fileNameInputB+".csv")

#Change absorbance data into transmittance for all dataframes
pureCW = (10**(-df_pureCW['Absorbance']))
pureC = 10**(-df_pureC['Absorbance'])
pureW = 10**(-df_pureW['Absorbance'])
pureIL = 10**(-df_pureIL['Absorbance'])
recIL = [[10**(-df_recIL['Trial 1'])],
        [10**(-df_recIL['Trial 2'])],
        [10**(-df_recIL['Trial 3'])]]
recCW = 10**(-df_recCW['Absorbance'])

#_________________________________________________________________________ FTIR FOR WOOL-COTTON, WOOL, COTTON, PRE-TREAT
#Create subplots of certain size
figLen = 15
figWid = 25
numOfList = 9
ind = 1
plt.subplots(figsize=(figLen, figWid))

#Setup FTIR plot for wool-cotton and wool and cotton
plt.subplot(numOfList, 1, ind)
ind +=1
plt.plot(wv, pureCW, 'k',label = "Pre-Treatment Cotton-Wool")
plt.plot(wv, pureC, 'b--',label="Pure Cotton")
plt.plot(wv, pureW, 'r--', label="Pure Wool")
plt.gca().invert_xaxis() #Invert x-axis
#Customize FTIR Data
plt.title("IR Spectra for Wool-Cotton Blend")
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')


#Compare FTIR for wool-cotton and wool and cotton at essential peak 1
plt.subplot(numOfList, 1, ind)
ind +=1
range1 = slice(wv[wv == 2000].index[0], wv[wv == 4000].index[0])
plt.plot(wv[range1], pureCW[range1], 'k',label = "Pre-Treatment Cotton-Wool")
plt.plot(wv[range1], pureC[range1], 'b--',label="Pure Cotton")
plt.plot(wv[range1], pureW[range1], 'r--', label="Pure Wool")
plt.gca().invert_xaxis() #Invert x-axis
plt.grid(visible=True, color='k')
#Customize FTIR Data
plt.title("IR Spectra for Wool-Cotton Blend (2000-4000 cm^-1)")
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')

#Compare FTIR for wool-cotton and wool and cotton at essential peak 2
plt.subplot(numOfList, 1, ind)
ind +=1
range2 = slice(wv[wv == 1400].index[0], wv[wv == 1900].index[0])
plt.plot(wv[range2], pureCW[range2], 'k',label = "Pre-Treatment Cotton-Wool")
plt.plot(wv[range2], pureC[range2], 'b--',label="Pure Cotton")
plt.plot(wv[range2], pureW[range2], 'r--', label="Pure Wool")
plt.gca().invert_xaxis() #Invert x-axis
plt.grid(visible=True, color='k')
#Customize FTIR Data
plt.title("IR Spectra for Wool-Cotton Blend (1400-1900 cm^-1)")
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')

#Compare FTIR for wool-cotton and wool and cotton at essential peak 3
plt.subplot(numOfList, 1, ind)
ind +=1
range3 = slice(wv[wv == 750].index[0], wv[wv == 1400].index[0])
plt.plot(wv[range3], pureCW[range3], 'k',label = "Pre-Treatment Cotton-Wool")
plt.plot(wv[range3], pureC[range3], 'b--',label="Pure Cotton")
plt.plot(wv[range3], pureW[range3], 'r--', label="Pure Wool")
plt.gca().invert_xaxis() #Invert x-axis
#Customize FTIR Data
plt.title("IR Spectra for Wool-Cotton Blend (750-1400 cm^-1)")
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')

#Compare pre- and post-treatment Cotton-Wool
plt.subplot(numOfList, 1, ind)
ind +=1
plt.plot(wv, pureCW, 'k',label = "Pre-Treatment Cotton-Wool")
plt.plot(wv, recCW, 'b--',label="Post-Treatment Cotton-Wool")
plt.gca().invert_xaxis() #Invert x-axis
#Customize FTIR Data
plt.title("IR Spectra for Pre- and Post-Treatment Cotton-Wool")
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')

#Compare FTIR for wool-cotton and wool and cotton at essential range 1
plt.subplot(numOfList, 1, ind)
ind +=1
minFocus=3000
maxFocus=3750
rangeCW = slice(wv[wv == minFocus].index[0], wv[wv == maxFocus].index[0])
plt.plot(wv[rangeCW], pureCW[rangeCW], 'b--',label="Pre-Treatment Cotton-Wool")
plt.plot(wv[rangeCW], recCW[rangeCW], 'r--', label="Post-Treatment Cotton-Wool")
plt.gca().invert_xaxis() #Invert x-axis
#Customize FTIR Data
plt.title("IR Spectra for Pre- and Post-Treatment Cotton-Wool ({}-{} cm^-1)".format(minFocus, maxFocus))
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')

#Compare FTIR for wool-cotton and wool and cotton at essential range 2
plt.subplot(numOfList, 1, ind)
ind +=1
minFocus=800
maxFocus=1800
rangeCW = slice(wv[wv == minFocus].index[0], wv[wv == maxFocus].index[0])
plt.plot(wv[rangeCW], pureCW[rangeCW], 'b--',label="Pre-Treatment Cotton-Wool")
plt.plot(wv[rangeCW], recCW[rangeCW], 'r--', label="Post-Treatment Cotton-Wool")
plt.gca().invert_xaxis() #Invert x-axis
#Customize FTIR Data
plt.title("IR Spectra for Pre- and Post-Treatment Cotton-Wool ({}-{} cm^-1)".format(minFocus, maxFocus))
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')
#_________________________________________________________________________ FTIR FOR IL PRE-TREAT AND AFTER RECYCLING
#Plot IL pre-treatment and recycling trials
plt.subplot(numOfList, 1, ind)
ind +=1
plt.plot(wv, pureIL, 'k',label = "Untreated IL")
plt.plot(wv, np.array(recIL[0]).reshape(-1), 'r:',label="Trial 1")
plt.plot(wv, np.array(recIL[1]).reshape(-1), 'g:', label="Trial 2")
plt.plot(wv, np.array(recIL[2]).reshape(-1), 'b:', label="Trial 3")
plt.gca().invert_xaxis() #Invert x-axis
#Customize FTIR Data
plt.title("IR Spectra for IL and Recycling Trials")
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')

#Compare FTIR for IL recycling trials at essential region
plt.subplot(numOfList, 1, ind)
ind +=1
minFocus=500
maxFocus=1750
rangeIL = slice(wv[wv == minFocus].index[0], wv[wv == maxFocus].index[0])
plt.plot(wv, pureIL, 'k-',label = "Untreated IL")
plt.plot(wv[rangeIL], np.array(recIL[0]).reshape(-1)[rangeIL], 'r:',label="Trial 1")
plt.plot(wv[rangeIL], np.array(recIL[1]).reshape(-1)[rangeIL], 'g:', label="Trial 2")
plt.plot(wv[rangeIL], np.array(recIL[2]).reshape(-1)[rangeIL], 'b:', label="Trial 3")
plt.xlim(minFocus, maxFocus)
plt.gca().invert_xaxis() #Invert x-axis
#Customize FTIR Data
plt.title("IR Spectra for IL and Recycling Trials ({}-{} cm^-1)".format(minFocus, maxFocus))
plt.xlabel("Wavelength (cm^-1)")
plt.ylabel("Transmittance")
plt.legend()
plt.grid(visible=True, color='k')

plt.tight_layout()

def identifyPeaks(data, waveMin, waveMax):
    '''
    Data is the array of intensities for each compound. waveMin is typically 400 and waveMax 4000 since that is the wavelength range
    scanned with this FTIR. Returns the actual wavelength measurements, and their indices in the original array
    '''
    threshold = .9
    peakIndex,_ = find_peaks(data, height = threshold)
    #Linearly scale the data to fit the wavelength range (typically 400 to 4000 cm^-1)
    peakWave = peakIndex*(waveMax-waveMin)/(len(data)+waveMin)
    return peakWave, peakIndex

waveMin = 400
waveMax = 4000
CWpeaks, peakIndex = identifyPeaks(pureCW, waveMin, waveMax)
#print(CWpeaks)

def charPeaks (peaks):
    '''
    This function will check each identified peaks against a table from ucle (https://www.chem.ucla.edu/~bacher/General/30BL/IR/ir.html)
    and identify the functional group each peak might be associated with
    '''
    for i in peaks:
        if 3100<=i<=3700:
            print("Peak at {:.4f} cm^-1 may be a water OH stretch".format(i))
        if 3200<=i<=3600:
            print("Peak at {:.4f} cm^-1 may be an alcohol OH stretch".format(i))
        if 2500<=i<=3600:
            print("Peak at {:.4f} cm^-1 may a carboxylic acid OH stretch".format(i))
        if 3350<=i<=3500:
            print("Peak at {:.4f} cm^-1 may be an N-H stretch".format(i))
        if .9<=i/3300<=1.1:
            #Checks if the peak is close to 3300, with a 10% allowable differece. May be subjective
            print("Peak at {:.4f} cm^-1 may be an alkyne C-H stretch".format(i))
        if 3000<=i<=3100:
            print("Peak at {:.4f} cm^-1 may be an alkene C-H stretch".format(i))
        if 2840<=i<=2950:
            print("Peak at {:.4f} cm^-1 may be an alkane C-H stretch".format(i))
        if 2800<=i<=2900:
            print("Peak at {:.4f} cm^-1 may be an aldhehydic C-H stretch".format(i))
        if .9<=i/2250<=1.1:
            #Checks if the peak is close to 2250, with a 10% allowable differece. May be subjective
            print("Peak at {:.4f} cm^-1 may be a nitrile group (C triple bonded N)".format(i))
        if 2100<=i<=2260:
            print("Peak at {:.4f} cm^-1 may be an alkyne C-C stretch".format(i))
        if 1720<=i<=1740:
            print("Peak at {:.4f} cm^-1 may be an aldehyde C=O".format(i))
        if 1740<=i<=1780 or 1800<=i<=1840:
            print("Peak at {:.4f} cm^-1 may be an anhydride C=O".format(i))
        if 1720<=i<=1750:
            print("Peak at {:.4f} cm^-1 may be an ester C=O".format(i))
        if 1715<=i<=1745:
            print("Peak at {:.4f} cm^-1 may be a ketone C=O".format(i))
        if 1500<=i<=1700:
            print("Peak at {:.4f} cm^-1 may be an amide C=O".format(i))
        if 1600<=i<=1680:
            print("Peak at {:.4f} cm^-1 may be an alkene C=C".format(i))
        if 1400<=i<=1600:
            print("Peak at {:.4f} cm^-1 may be an aromatic C=C".format(i))
        if 1440<=i<=1480:
            print("Peak at {:.4f} cm^-1 may be a CH2 bend".format(i))
        if 1440<=i<=1465 or 1365<=i<=1390:
            print("Peak at {:.4f} cm^-1 may be a CH3 bend".format(i))
        if 1050<=i<=1250:
            print("Peak at {:.4f} cm^-1 may be a C-O-C stretch".format(i))
        if 1020<=i<=1200:
            print("Peak at {:.4f} cm^-1 may be a C-OH stretch".format(i))
        if 1300<=i<=1400:
            print("Peak at {:.4f} cm^-1 may be an NO2 stretch".format(i))
        if 1000<=i<=1400:
            print("Peak at {:.4f} cm^-1 may be a C-F bond".format(i))
        if 600<=i<=800:
            print("Peak at {:.4f} cm^-1 may be a C-Cl bond".format(i))
        if 500<=i<=750:
            print("Peak at {:.4f} cm^-1 may be a C-Br bond".format(i))
        if .9<=i/500<=1.1:
            print("Peak at {:.4f} cm^-1 may be a C-I bond".format(i))
        print("\n")
    return

#charPeaks(CWpeaks)